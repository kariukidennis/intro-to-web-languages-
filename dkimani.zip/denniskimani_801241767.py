import string
from typing import Counter

#Program 1
def string_ends(str):

  if len(str) < 2:
    return "input more words"

  return str[0:2] + str[-2:]

print(string_ends('python'))
print(string_ends('py'))
print(string_ends('p'))  
print()
#Program 2
start = int(1000)
end = int(1100)

for i in range(start,end):
    if i%7 == 0 and i%5 != 0:
        print(i, "is divisible by 7 but not 5")
print()

#Program 3
first =  {'a': 100, 'b': 200, 'c': 300}
second = {'a': 300, 'b': 200, 'd': 400}

dictionary = Counter(first) + Counter(second)
print(dictionary)

#Program 4
itemlist = []
item = int(input("input the number of items:"))
for i in range(item):
    price = input("key in the item and price:")

    itemprices = price = price.split()
    itemlist.append(itemprices)

itemlist = sorted(itemlist, key= lambda x:x[1])
for i in itemlist:
 print(i[0],i[1])

        